#! /usr/bin/python3
import cv2
import numpy as np
import time
import geometry_msgs.msg
from geometry_msgs.msg import Twist
import rospy
from sensor_msgs.msg import Image
from std_msgs.msg import Int8
from car_msgs.msg import YoloDetect
# from car_msgs.msg import LastLine
yolo_detect_ = YoloDetect()


class yolo_detector:
    def __init__(self, config):
        print('Net use', config['netname'])
        self.confThreshold = config['confThreshold'print
        self.nmsThreshold = config['nmsThreshold']
        self.inpWidth = config['inpWidth']
        self.inpHeight = config['inpHeight']
        with open(config['classesFile'], 'rt') as f:
            self.classes = f.read().rstrip('\n').split('\n')
        self.colors = [np.random.randint(0, 255, size=3).tolist() for _ in range(len(self.classes))]
        self.net = cv2.dnn.readNet(config['modelConfiguration'], config['modelWeights'])
        self.mode = -1
        self.lastline_ = 0


    def drawPred(self, frame, classId, conf, left, top, right, bottom):
        # Draw a bounding box.
        cv2.rectangle(frame, (left, top), (right, bottom), (0, 0, 255), thickness=3)
        label = '%.2f' % conf
        label = '%s:%s' % (self.classes[classId], label)
        # Display the label at the top of the bounding box
        labelSize, baseLine = cv2.getTextSize(label, cv2.FONT_HERSHEY_SIMPLEX, 0.5, 1)
        top = max(top, labelSize[1])
        # cv.rectangle(frame, (left, top - round(1.5 * labelSize[1])), (left + round(1.5 * labelSize[0]),
        # top + baseLine), (255,255,255), cv.FILLED)
        cv2.putText(frame, label, (left, top - 10), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), thickness=2)
        return frame

    # Remove the bounding boxes with low confidence using non-maxima suppression
    def postprocess(self, frame, outs,yolo_detect):
        frameHeight = frame.shape[0]
        frameWidth = frame.shape[1]
        classIds=[]
        confidences=[]
        boxes=[] 
        results = []
        centerxy_0=[]
        centerxy_1 =[]
        centerx_0=[]
        centerx_1 = []
        lefts=[]
        tops=[]
        widths=[]
        heights=[]
        ID=[]
        areas = []
        for out in outs:
            for detection in out:
                scores = detection[5:]
                classId = np.argmax(scores)
                confidence = scores[classId]
                if confidence > self.confThreshold:
                    center_x = int(detection[0] * frameWidth)
                    center_y = int(detection[1] * frameHeight)
                    # print(center_x, center_y)
                    width = int(detection[2] * frameWidth)
                    height = int(detection[3] * frameHeight)
                    # print(width, height)
                    left = int(center_x - width / 2)
                    top = int(center_y - height / 2)
                    classIds.append(classId)
                    confidences.append(float(confidence))
                    boxes.append([left, top, width, height])
        indices = cv2.dnn.NMSBoxes(boxes, confidences, self.confThreshold, self.nmsThreshold)

        for i in indices:
            i = i[0]
            box = boxes[i]
            left = box[0]
            top = box[1]
            width = box[2]
            height = box[3]
            # self.drawPred(frame, classIds[i], confidences[i], left, top, left + width, top + height)
            center_x = left + round(width / 2)
            center_y = top + round(height / 2)
            lefts.append(left)
            tops.append(top)
            heights.append(height)
            # print(height)
            widths.append(width)
            areas.append(height*width)
            ID.append(classIds[i])
            results.append([classIds[i], center_x, center_y])
        if len(results) > 0:
            for result in results:
                if result[0] == 0:  # and result[1] * result[2] > frameWidth * frameHeight * 0.1:
                    centerxy_0.append((result[1], result[2]))
                elif result[0] == 1:  # and result[1] * result[2] > frameWidth * frameHeight * 0.1:
                    centerxy_1.append((result[1], result[2]))
            centerxy_0.sort()
            centerxy_1.sort()

        else:
            cv2.putText(frame, "nothing found", (round(frame.shape[1] / 10), round(frame.shape[0] * 0.9)),
                        cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), thickness=2)
        roi = np.argsort(areas)
        # print(roi)
        yolo_detect_.header.stamp = rospy.Time.now()
        yolo_detect_.header.frame_id = "base_link"
        for i in range(0, 4):
                yolo_detect.left[i] = 0
                yolo_detect.top[i] = 0
                yolo_detect.width[i] = 0
                yolo_detect.height[i] = 0    
                yolo_detect.ID[i] = 0       
        for i in range(0, len(roi)):
            if(i<4):
                yolo_detect.left[i] = lefts[roi[i]]
                yolo_detect.top[i] = tops[roi[i]]
                yolo_detect.width[i] = widths[roi[i]]
                yolo_detect.height[i] = heights[roi[i]]
                yolo_detect.ID[i] = ID[roi[i]]
            else:
                break

    def detect(self, src_img):
        blob = cv2.dnn.blobFromImage(src_img, 1 / 255.0, (self.inpWidth, self.inpHeight), [0, 0, 0], swapRB=True,
                                     crop=False)
        # Sets the input to the network
        self.net.setInput(blob)
        # Runs the forward pass to get output of the output layers
        outs = self.net.forward(self.net.getUnconnectedOutLayersNames())
        self.postprocess(src_img, outs,yolo_detect_)
        return src_img

    def LastLinecallback(self,LastLine):
        self.lastline_ = LastLine.data
        print(yolo_net.lastline_)
        while not (rospy.is_shutdown()) and yolo_net.lastline_>=7:
            print("-----------------------------Detecting stop----------------------------")
            ret, frame = cap.read()
            if ret == 1:
                src_img = yolo_net.detect(frame)
                winName = 'Deep learning object detection in OpenCV'
                cv2.imshow(winName, src_img)
                cv2.waitKey(1)
                detect_info_pub.publish(yolo_detect_)


Net_config = [
    {'confThreshold': 0.5, 
    'nmsThreshold': 0.5, 
    'inpWidth': 320, 
    'inpHeight': 320, 
    'classesFile': '/home/racecar/racecar_zzx/src/detect_yolo/model/class_yolov4.txt',
    'modelConfiguration': '/home/racecar/racecar_zzx/src/detect_yolo/model/yolov4-tiny-stop.cfg', 
    'modelWeights': '/home/racecar/racecar_zzx/src/detect_yolo/model/yolov4-tiny-stop_final.weights',
    'netname': 'yolov4-tiny'}]

if __name__ == "__main__":
    cap = cv2.VideoCapture(0)
    net_type = 0
    yolo_net = yolo_detector(Net_config[net_type])
    
    
#------------------------------------run-----------------------------------------#
    rospy.init_node('yolo_detect', anonymous=True)
    detect_info_pub = rospy.Publisher('/detect/yolo_detect', YoloDetect, queue_size=10)
    stop_flag_pub = rospy.Subscriber('/flag',Int8,yolo_net.LastLinecallback)
    rospy.spin()

#-------------------------------------test-------------------------------------#
   # while not (rospy.is_shutdown()):
        #time1 = time.time()
        #print("-----------------------------Detecting stop----------------------------")
       # ret, frame = cap.read()
        #if ret == 1:
            # yolo_net.color_space_red(frame)
            # yolo_net.color_space_blue(frame)
            #src_img = yolo_net.detect(frame)
            #time2 = time.time()
            #fps = 1 / (time2 - time1)
            #text = 'FPS:%.2f' % fps
            #winName = 'Deep learning object detection in OpenCV'
            #cv2.putText(src_img, text, (50, 50), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 1)
            #cv2.imshow(winName, src_img)
            #cv2.waitKey(1)
            # detect_info_pub.publish(yolo_detect_)
            # rate.sleep()


